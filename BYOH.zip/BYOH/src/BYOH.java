import java.util.ArrayList;
import java.util.Scanner;

public class BYOH {

    public static void main(String[] arg) {
        // Variable Declarations
        String slogan = "Build Your Own Hoagies,Your way. Time to build a hoagie.";

        boolean isVegan = true;

        //============= Array List of Ingredients =================
        //Rolls
        ArrayList<String> rolls = new ArrayList<String>();
        rolls.add("White");
        rolls.add("Wheat");
        rolls.add("Sesame");
        //Meats
        ArrayList<String> meats = new ArrayList<String>();
        meats.add("Ham");
        meats.add("Chicken");
        meats.add("Veggie");
        //Toppings
        ArrayList<String> toppings = new ArrayList<String>();
        toppings.add("Cheese");
        toppings.add("Lettuce");
        toppings.add("Tomatoes");
        toppings.add("Onions");
        toppings.add("Bacon");
        toppings.add("Mayonnaise");

        // Greet Customer and give slogan
        System.out.println();
        System.out.println("Welcome to " + slogan);

        //=============================================================
        //                     Ordering Process
        //=============================================================
        Scanner input = new Scanner(System.in);

        // Rolls Selection
        System.out.println("Here is our selection of Rolls: ");
        MenuDisplay(rolls);

        System.out.println("What type of Roll would you like? ");
        String rollSelection = input.next();

        // Meats Selection
        System.out.println("Here are our meat options: ");
        MenuDisplay(meats);

        System.out.println("What meat option will you be going with? ");
        String meatSelection = input.next();

        if (meatSelection.equals("Ham") || meatSelection.equals("ham") || meatSelection.equals("Chicken") || meatSelection.equals("chicken")){
            isVegan = false;
        }

        // Toppings
        System.out.println("Here is a list of our toppings: ");
        MenuDisplay(toppings);

        // While loop for topping selection
        ArrayList<String> toppingSelection = new ArrayList<String>();
        boolean wantsMoreToppings = true;
        while (wantsMoreToppings) {
            System.out.println("Which toppings would you like? ");
            String toppingChoice = input.next();
            toppingSelection.add(toppingChoice);

            System.out.println("Do you want any more toppings? ");
            String addMoreToppings = input.next();

            if (addMoreToppings.equals("Yes") || addMoreToppings.equals("yes")){
                wantsMoreToppings = true;
            }else{
                wantsMoreToppings = false;
            }

            if (toppingChoice.equals("Cheese") || toppingChoice.equals("cheese") || toppingChoice.equals("Bacon") || toppingChoice.equals("bacon") || toppingChoice.equals("Mayo") || toppingChoice.equals("mayo")){
                isVegan = false;
            }

        }

        // ================= Order Display ================
        System.out.println("That will be a " + meatSelection + " on " + rollSelection + " roll Hoagie.");
        System.out.println("topped with: ");
        if (toppingSelection.size() > 0 ){
            for (String toppingDisplay : toppingSelection){
                System.out.println(toppingDisplay);
            }
        }

        if (isVegan){
            System.out.println("Thank You for trying our vegan Hoagie!");
        }else{
            System.out.println("Thank for ordering from Build Your Own Hoagie!");
        }
    }// end of Main

    //================ Menu Display ===================
    private static void MenuDisplay(ArrayList<String> menu){
        for (String ingredients : menu){
            System.out.println(ingredients + "\n");
        }
    }


}//end of class
